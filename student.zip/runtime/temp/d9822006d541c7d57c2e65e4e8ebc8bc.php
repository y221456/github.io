<?php /*a:2:{s:51:"D:\phpstudy_pro\WWW\student\app\view\user\user.html";i:1620140073;s:55:"D:\phpstudy_pro\WWW\student\app\view\public\header.html";i:1611404878;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo getSystemSetInfo('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="/assets/images/favicon.ico">

    <!-- third party css -->
    <link href="/assets/css/vendor/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- third party css end -->
    <link href="/assets/css/vendor/dataTables.bootstrap4.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/vendor/responsive.bootstrap4.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/vendor/buttons.bootstrap4.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/vendor/select.bootstrap4.css" rel="stylesheet" type="text/css" />
    <!-- App css -->
    <link href="/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/app.min.css" rel="stylesheet" type="text/css" />

</head>

<style>
    ::-webkit-scrollbar { width: 0 !important }
    .mo{
        cursor:pointer;
    }
</style>
<body>
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">数据表格</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->


    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">账号管理</h4>
                    <p class="text-muted font-14 mb-4">
                        该数据表为账号信息，包含各类用户账号信息<br>
                        若有未录入账号，<code class="mo" >点击这里进行添加</code>
                    </p>

                    <table id="basic-datatable" class="table dt-responsive nowrap" width="100%">
                        <thead>
                        <tr>
                            <th>Id</th>
                            <th>账号</th>
                            <th>权限</th>
                            <th>操作</th>
                        </tr>
                        </thead>


                        <tbody id="studentData">
                        <?php foreach($userList as $key=>$value):
                            $Id=$value['Id'];
                        ?>
                        <tr>
                            <td data-name="Id" data-val="<?php echo htmlentities($value['Id']); ?>"><?php echo htmlentities($value['Id']); ?></td>
                            <td data-name="username" data-val="<?php echo htmlentities($value['username']); ?>"><?php echo htmlentities($value['username']); ?></td>

                            <td data-name="power" data-val="<?php echo htmlentities($value['power']); ?>"><?php
                                     if( $value['power']==999){
                                        echo "管理员";
                                     }else if($value['power']==998){
                                        echo "老师";
                                     }else{
                                         echo "学生";
                                     }
                            ?></td>
                            <td class="table-action">
                                <a href="javascript: void(0);"  class="action-icon"> <i class="mdi mdi-pencil"></i></a>
                                <a href="javascript: void(0);"> <i class="mdi mdi-delete"></i></a>
                            </td>
                        </tr>
                       <?php endforeach; ?>
                        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->
    <div id="signup-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-body">
                    <div class="text-center mt-2 mb-4">
                        <a href="index.html" class="text-success">
                            <span><img src="assets/images/logo-dark.png" alt="" height="18"></span>
                        </a>
                    </div>

                    <!--<form class="pl-3 pr-3" action="#">-->
                        <div class="form-group" style="display: none;">
                            <label for="f-Id">Id</label>
                            <input class="form-control" type="text" id="f-Id" name="Id" required="" value="" >
                        </div>
                        <div class="form-group">
                            <label for="f-name">名字</label>
                            <input class="form-control" type="text" id="f-name" name="name" required="" placeholder="请输入名字">
                        </div>
                        <div class="form-group">
                            <label for="f-header">头像地址</label>
                            <input class="form-control" type="text" id="f-header" name="header" required="" placeholder="请输入头像地址">
                        </div>
                        <div class="form-group">
                            <label for="f-number">学号</label>
                            <input class="form-control" type="text"  id="f-number" name="number" required="" placeholder="请输入学号">
                        </div>
                        <div class="form-group">
                            <label for="f-id_card">身份证</label>
                            <input class="form-control" type="text"  id="f-id_card" name="id_card" required="" placeholder="请输入身份证">
                        </div>
                        <div class="form-group">
                            <label for="f-sex">性别</label>
                            <select class="select2 form-control select2-multiple" data-toggle="select2" name="sex" id="f-sex"  data-placeholder="选择 ...">
                                    <option value="男">男</option>
                                    <option value="女">女</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="f-teacher">辅导员</label>
                            <input class="form-control" type="email"  id="f-teacher" name="teacher"  placeholder="请输入辅导员">
                        </div>
                        <div class="form-group">
                            <label for="f-class">班级</label>
                            <input class="form-control" type="text"  id="f-class" name="class"  placeholder="请输入班级">
                        </div>
                        <div class="form-group">
                            <label for="f-dormitory">宿舍</label>
                            <input class="form-control" type="text"   id="f-dormitory"name="dormitory" placeholder="请输入宿舍">
                        </div>
                        <div class="form-group">
                            <label for="f-major">专业</label>
                            <input class="form-control" type="text"  id="f-major" name="major" placeholder="请输入专业">
                        </div>
                        <div class="form-group">
                            <label for="f-college">学院</label>
                            <input class="form-control" type="text"  id="f-college"  name="college" placeholder="请输入学院">
                        </div>


                        <div class="form-group text-center">
                            <button class="btn btn-primary" type="button" onclick="infoPost()" id="infoPost">保存</button>
                        </div>

                    <!--</form>-->

                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <div id="primary-header-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="primary-header-modalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header modal-colored-header bg-primary">
                    <h4 class="modal-title" id="primary-header-modalLabel">提示</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                    <p>删除后无法恢复，你确定要删除该信息吗？</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-dismiss="modal">取消</button>
                    <button type="button" class="btn btn-primary" onclick="sendDelete()">确定</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- end row-->


</div> <!-- container -->
<!-- third party js -->
<script src="/assets/js/app.min.js"></script>
<script src="/assets/js/vendor/jquery.dataTables.min.js"></script>
<script src="/assets/js/vendor/dataTables.bootstrap4.js"></script>
<script src="/assets/js/vendor/dataTables.responsive.min.js"></script>
<script src="/assets/js/vendor/responsive.bootstrap4.min.js"></script>
<script src="/assets/js/vendor/dataTables.buttons.min.js"></script>
<script src="/assets/js/vendor/buttons.bootstrap4.min.js"></script>
<script src="/assets/js/vendor/buttons.html5.min.js"></script>
<script src="/assets/js/vendor/buttons.flash.min.js"></script>
<script src="/assets/js/vendor/buttons.print.min.js"></script>
<script src="/assets/js/vendor/dataTables.keyTable.min.js"></script>
<script src="/assets/js/vendor/dataTables.select.min.js"></script>
<!-- third party js ends -->

<!-- demo app -->
<script src="/assets/js/pages/demo.datatable-init.js"></script>
<!--<script src="/static/main.js"></script>-->
<script>
    let inputId={};// 存储点击列表某一条的数据
    let inputKey = ["Id", "name", "header", "number", "id_card", "sex", "teacher", "class", "dormitory", "major", "college"];
    let fromClickType = 0;  // 1 就是新增 0 就是修改
    let deleteId=null;  //要删除的信息ID
    // 点击添加信息
    function addClick() {
        fromClickType=1;
        $('#infoPost').text('添加');
        for(let item in inputId){
            $("#f-"+item).val("");
        }
    }
    // 删除信息点击
    function deleteClick(e,Id){
        deleteId=Id;
    }
    function sendDelete() {
        if(deleteId===null){
            $.NotificationApp.send("未知错误,请刷新重试",data.msg, "top-center", "rgba(0,0,0,0.2)", "error")
            return;
        }
        console.log(deleteId)
        $.ajax({
            url:  "/student/delete",
            data: {
                Id:deleteId
            },
            type: "GET",
            success: function(data) {
                if(data.code==200){
                    $.NotificationApp.send("删除成功",data.msg, "top-center", "rgba(0,0,0,0.2)", "success");
                    setTimeout(()=>{
                        window.location.href="/student/student"
                    },1000)
                }else{
                    $.NotificationApp.send("错误",data.msg, "top-center", "rgba(0,0,0,0.2)", "error")
                }
            },error:function (e) {
                const data = e.responseJSON;
                $.NotificationApp.send("错误",data.msg, "top-center", "rgba(0,0,0,0.2)", "error")
            }
        });
    }
    // 信息提交
    function infoPost() {
        if(fromClickType===1){
            let data = {};
            for(let item of inputKey){
                data[item]=$("#f-"+item).val();
            }
            $.ajax({
                url:  "/student/add",
                data,
                type: "POST",
                dataType: "json",
                success: function(data) {
                    if(data.code==200){
                        $.NotificationApp.send("添加成功",data.msg, "top-center", "rgba(0,0,0,0.2)", "success");
                        for(let item of inputKey){
                            $("#f-"+item).val("");
                        }
                        $('.modal-backdrop').remove();
                        $('#signup-modal').removeClass('show');
                        $('#signup-modal').css("display",'none')
                    }else{
                        $.NotificationApp.send("错误",data.msg, "top-center", "rgba(0,0,0,0.2)", "error")
                    }
                },error:function (e) {
                    const data = e.responseJSON;
                    $.NotificationApp.send("错误",data.msg, "top-center", "rgba(0,0,0,0.2)", "error")
                }
            });
        }else{
            let data = {};
            for(let item of inputKey){
                data[item]=$("#f-"+item).val();
            }
            $.ajax({
                url:  "/student/update",
                data,
                type: "POST",
                dataType: "json",
                success: function(data) {
                    if(data.code==200){
                        $.NotificationApp.send("修改成功",data.msg, "top-center", "rgba(0,0,0,0.2)", "success");
                        setTimeout(()=>{
                            window.location.href="/student/student"
                        },1000)
                    }else{
                        $.NotificationApp.send("错误",data.msg, "top-center", "rgba(0,0,0,0.2)", "error")
                    }
                },error:function (e) {
                    const data = e.responseJSON;
                    $.NotificationApp.send("错误",data.msg, "top-center", "rgba(0,0,0,0.2)", "error")
                }
            });
        }
    }
    function editClick(e,Id){
        fromClickType=0;
        $('#infoPost').text('保存');
        $.ajax({
            url:  "/student/getStudentOne",
            data: {
               Id
            },
            type: "GET",
            success: function(data) {
                if(data.code==200){
                    inputId=data.data[0];
                    for(let item in data.data[0]){
                        $("#f-"+item).val(data.data[0][item])
                    }
                }else{
                    $.NotificationApp.send("错误",data.msg, "top-center", "rgba(0,0,0,0.2)", "error")
                }
            },error:function (e) {
                const data = e.responseJSON;
                $.NotificationApp.send("错误",data.msg, "top-center", "rgba(0,0,0,0.2)", "error")
            }
        });
    }
</script>
</body>

</html>