<?php /*a:2:{s:54:"D:\phpstudy_pro\WWW\student\app\view\system\index.html";i:1611407024;s:55:"D:\phpstudy_pro\WWW\student\app\view\public\header.html";i:1611404878;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo getSystemSetInfo('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="/assets/images/favicon.ico">

    <!-- third party css -->
    <link href="/assets/css/vendor/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- third party css end -->
    <link href="/assets/css/vendor/dataTables.bootstrap4.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/vendor/responsive.bootstrap4.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/vendor/buttons.bootstrap4.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/vendor/select.bootstrap4.css" rel="stylesheet" type="text/css" />
    <!-- App css -->
    <link href="/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/app.min.css" rel="stylesheet" type="text/css" />

</head>
<style>
    ::-webkit-scrollbar { width: 0 !important }
</style>
<body>
<div>
    <div class="content" style="margin-top: 50px">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <!--<h4 class="header-title">网站设置</h4>-->
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group mb-3">
                                    <label>网站标题</label>
                                    <input type="text" class="form-control" value="<?php echo htmlentities($system['title']); ?>"
                                           id="f-title"
                                           data-provide="typeahead" placeholder="输入网站的标题">
                                </div>
                            </div> <!-- end col -->

                            <div class="col-lg-6 mt-3 mt-lg-0">
                                <div class="form-group mb-3">
                                    <label>导航条标题</label>
                                    <input class="form-control" value="<?php echo htmlentities($system['nav_title']); ?>" type="text"
                                           id="f-nav_title"
                                           placeholder="请填写你的导航条标题">
                                </div>
                            </div> <!-- end col -->
                        </div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group mb-3">
                                    <label>底部版权</label>
                                    <input type="text" class="form-control" value="<?php echo htmlentities($system['footer']); ?>" id="f-footer" data-provide="datepicker">
                                </div>
                            </div>

                        </div>
                        <!-- end row -->
                    </div> <!-- end card-->
                    <div style="margin: 20px">
                        <button class="btn btn-block btn-primary" type="button" onclick="infoPost()" id="infoPost">提交
                        </button>
                    </div>
                </div> <!-- end col -->

            </div>
        </div>
    </div>
</div>
<!-- App js -->
<script src="/assets/js/app.min.js"></script>

<script src="/assets/js/vendor/handlebars.min.js"></script>
<script src="/assets/js/vendor/typeahead.bundle.min.js"></script>
<script>
    let info = ['title','nav_title','footer'];
    function infoPost() {
        let data = {};
        info.forEach(item=>{
            data[item]=$('#f-'+item).val();
        })
        $.ajax({
            url:  "/system/update",
            data,
            type: "POST",
            dataType: "json",
            success: function(data) {
                if(data.code==200){
                    $.NotificationApp.send("修改成功",data.msg, "top-center", "rgba(0,0,0,0.2)", "success");
                    setTimeout(()=>{
                        window.location.href="/system/index"
                    },1000)
                }else{
                    $.NotificationApp.send("错误",data.msg, "top-center", "rgba(0,0,0,0.2)", "error")
                }
            },error:function (e) {
                const data = e.responseJSON;
                $.NotificationApp.send("错误",data.msg, "top-center", "rgba(0,0,0,0.2)", "error")
            }
        });
    }
</script>
</body>
</html>